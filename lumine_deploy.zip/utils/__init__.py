"""Shared bot infrastructure helpers."""
